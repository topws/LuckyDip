//
//  ViewController.m
//  Prize
//
//  Created by 钱卫 on 16/3/8.
//  Copyright © 2016年 钱卫. All rights reserved.
//

#import "ViewController.h"
#import "UIView+Additions.h"
@interface ViewController ()


//存放随机数的数组
@property (nonatomic,strong)NSArray * nums;
//改变当前数组值得标记
@property (nonatomic,assign)int flag1;
@property (nonatomic,assign)int flag2;

//当前选择动画的个数
@property (nonatomic,assign)int chooseNum;
//动画定时器
@property(nonatomic,strong)NSTimer *timer;

//存放动画视图的数组
@property(nonatomic,strong)NSMutableArray * imageViews;
@property(nonatomic,strong)NSMutableArray * labels;
@property(nonatomic,strong)NSMutableArray * chooseBtn;

//开始结束按钮
@property(nonatomic,weak)UIButton * startBtn;
@property(nonatomic,weak)UIButton * endBtn;

//获奖名单
@property(nonatomic,weak)UITextView * prizeLabel;
@end

@implementation ViewController
//懒加载
-(NSArray *)nums{
    if (_nums == nil) {
        _nums = [NSArray array];
    }
    return _nums;
}
-(NSMutableArray *)imageViews{
    if (_imageViews == nil) {
        _imageViews = [NSMutableArray array];
    }
    return _imageViews;
}
-(NSMutableArray *)labels{
    if (_labels == nil) {
        _labels = [NSMutableArray array];
    }
    return _labels;
}
-(NSMutableArray *)chooseBtn{
    if (_chooseBtn == nil) {
        _chooseBtn = [NSMutableArray array];
    }
    return _chooseBtn;
}
#pragma mark - 加载视图
- (void)viewDidLoad {
    [super viewDidLoad];
    //获取随机数列表
    self.nums = [self makeArcdom:10];
    self.flag1 = 0;
    self.flag2 = 0;
    self.chooseNum = 0;
    [self setupUI];
    
    //隐藏屏幕上的的动画
    for (int i = 0; i<8; i++) {
        UIImageView * view = self.imageViews[i];
        view.hidden = YES;
    }
}

-(void)setupUI{
    //创建一个背景图
    UIView * backView = [[UIView alloc]initWithFrame:CGRectMake(0, 80, self.view.bounds.size.width, 132)];
    backView.backgroundColor = [UIColor darkGrayColor];
    backView.clipsToBounds = YES;
    [self.view addSubview:backView];
    
    //创建动画图
    CGFloat margin = 26;
    CGFloat viewH = 80;
    CGFloat viewW = viewH;
    for (int i = 0; i < 8; i++) {
        UIImageView * view = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"kuang"]];
        int col = i %4;
        int row = i /4;
        view.frame = CGRectMake(13+col * (viewW +13), margin+row * (viewW +margin), viewW, viewH);
        //填加label
        UILabel * label = [[UILabel alloc]init];
        label.font = [UIFont systemFontOfSize:40];
//        label.text = @"33";
        label.frame = CGRectMake(15, 10, 60, 60);
        [view addSubview:label];
        
        [backView addSubview:view];
        [self.imageViews addObject:view];
        [self.labels addObject:label];
    
    }
    
    //按钮
    [self createBtns];
    
    //输出获奖名单
    UIImageView * prizeImageView =[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"detail1"]];
    prizeImageView.frame = CGRectMake(40, 410,100,30);
    [self.view addSubview:prizeImageView];
    
    UITextView * prizeLabel = [[UITextView alloc]init];
    prizeLabel.frame = CGRectMake(40, 440, 300,200);
//    prizeLabel.numberOfLines = 0;
    prizeLabel.backgroundColor = [UIColor redColor];
    self.prizeLabel = prizeLabel;
    [self.view addSubview:prizeLabel];

}
//创建所以得按钮
-(void)createBtns{
    //创建四个控制个数的按钮
    for (int i = 0; i<4; i++) {
        UIButton * btn = [[UIButton alloc]init];
        btn.frame = CGRectMake(20 + i * 90, 300, 40, 40);
        btn.backgroundColor = [UIColor orangeColor];
        [btn setTitle:[NSString stringWithFormat:@"%d",i+1] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        btn.layer.cornerRadius = 20;
        btn.clipsToBounds = YES;
        UIImage * image =[UIImage imageNamed:@"btn"];
        btn.contentMode = UIViewContentModeCenter;
        [btn setBackgroundImage:image forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(chooseNum:) forControlEvents:UIControlEventTouchUpInside];
        [self.chooseBtn addObject:btn];
        [self.view addSubview:btn];
    }
    //开始结束动画按钮
    UIButton * startBtn =[[UIButton alloc]initWithFrame:CGRectMake(100, 370, 60, 40)];
    [startBtn setTitle:@"开始" forState:UIControlStateNormal];
    [startBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [startBtn addTarget:self action:@selector(start) forControlEvents:UIControlEventTouchUpInside];
    [startBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
    startBtn.enabled = NO;
    [self.view addSubview:startBtn];
    
    UIButton * endBtn =[[UIButton alloc]initWithFrame:CGRectMake(180, 370, 60, 40)];
    [endBtn setTitle:@"结束" forState:UIControlStateNormal];
    [endBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [endBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
    [endBtn addTarget:self action:@selector(end) forControlEvents:UIControlEventTouchUpInside];
    endBtn.enabled = NO;
    [self.view addSubview:endBtn];
    
    //配置按钮
    UIButton * reSet =[[UIButton alloc]initWithFrame:CGRectMake(300, 340, 80, 80)];
    [reSet setTitle:@"配置" forState:UIControlStateNormal];
    [reSet setBackgroundImage:[UIImage imageNamed:@"pzbtu_zc"] forState:UIControlStateNormal];
    [reSet addTarget:self action:@selector(reSet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:reSet];
    
    self.startBtn = startBtn;
    self.endBtn = endBtn;
    
}
#pragma mark -重新配置
-(void)reSet{
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"该功能有待完善" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //移除掉
        [alert dismissViewControllerAnimated:YES completion:^{
            
        }];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    
}
#pragma  mark - 开始结束
-(void)start{
    NSLog(@"%s",__func__);
    //判断是否存在禁用的选择按钮
    int disableChooseBtn =0;
    for (int i = 0; i<self.chooseBtn.count; i++) {
        UIButton * btn = self.chooseBtn[i];
        if (btn.enabled == NO) {
            disableChooseBtn++;
        }
    }
    NSLog(@"%d",disableChooseBtn);
    //由于禁用必然是从第四个开始的，所以禁用的状态决定了能否继续执行
        if (disableChooseBtn)
    {
        switch (disableChooseBtn) {
            case 1:
                if (self.chooseNum == 4) {
                    [self remindMessage:@"请重新选择"];
                    return;
                }
                break;
            case 2:
                if (self.chooseNum>2) {
                    [self remindMessage:@"请重新选择"];
                    return;
                }
                break;
            case 3:
                if (self.chooseNum>1) {
                    [self remindMessage:@"请重新选择"];
                    return;
                }
                break;

            default:
                break;
        }
    }
    //开启动画
    
    //创建一个定时器
    NSTimer * timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(animationStart) userInfo:nil repeats:YES];
    
    self.timer = timer;
  
}
-(void)end{
    NSLog(@"%s",__func__);
    //结束
    [self.timer invalidate];
    self.timer = nil;
    
    //追加减速动画
        //移动的距离(可考虑封装动画效果代码)
    
    //判断开启几个按钮
    for (int i =0; i<self.chooseNum; i++) {
        [self animation:i];
    }

}
#pragma mark -封装减速动画
-(void)animation:(int)i{
     NSLog(@"%s",__func__);
    //开始之前，让下面的数字为正确的，结束后无缝替换
    UILabel * label = self.labels[i+4];
    label.text = self.nums[self.flag1];
    //每一次的计算都让标记加一，如果标记等于10，就不能继续动画
    self.flag1++;
    
    [UIView animateKeyframesWithDuration:(1.4+0.9*i) delay:0.0 options:UIViewKeyframeAnimationOptionCalculationModePaced animations:^{
        
        UIImageView * view1 = self.imageViews[i];
        view1.y -= 106;
        UIImageView * view2 = self.imageViews[i+4];
        view2.y -= 106;
        
//        UILabel * label1 = self.labels[i];
//        label1.text = [NSString stringWithFormat:@"%d",arc4random_uniform(100)];
//        UILabel * label2 = self.labels[i+4];
//        label2.text = [NSString stringWithFormat:@"%d",arc4random_uniform(100)];
        
    } completion:^(BOOL finished) {
        UIImageView * view1 = self.imageViews[i];
        view1.y += 106;
        UIImageView * view2 = self.imageViews[i+4];
        view2.y += 106;
        //设置数值
        UILabel * label = self.labels[i];
        label.text = self.nums[self.flag2];
        //每一次的计算都让标记加一，如果标记等于10，就不能继续动画
        self.flag2 ++;
        
        for (UIView * view in self.view.subviews) {
            view.userInteractionEnabled = YES;
        }
        //全部动画结束后，应该启用相关按钮
        self.endBtn.enabled = NO;
        self.startBtn.enabled = YES;
        //判断当前剩下的值
        if ((self.nums.count - self.flag1)<4) {
            switch (self.nums.count - self.flag1) {
                case 3:
                {
                    UIButton * btn = self.chooseBtn[3];
                    btn.enabled = NO;
                }
                    break;
                case 2:
                {   UIButton * btn1 = self.chooseBtn[3];
                    btn1.enabled = NO;
                    UIButton * btn2 = self.chooseBtn[2];
                    btn2.enabled = NO;
                }

                    break;
                case 1:
                {
                    for (int i =1; i<4; i++) {
                        UIButton * btn1 = self.chooseBtn[i];
                        btn1.enabled = NO;
                    }
                }
                    break;
                default:
                {
                    for (int i =0; i<4; i++) {
                        UIButton * btn1 = self.chooseBtn[i];
                        btn1.enabled = NO;
                    }
                    //让开始按钮禁用
                    self.startBtn.enabled = NO;
                    //判断是否能够开启动画
                    
                    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"中奖人数暂固定为十人" preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction * action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    [alert addAction:action];
                    [self presentViewController:alert animated:YES completion:nil];

                }

                    break;
            }
        }
        //代码执行完毕后，就让选择值归0
        //self.chooseNum = 0;
        
        //输出获奖名单
        NSMutableAttributedString * result = [NSMutableAttributedString new];
        for (int i =0; i<self.flag1; i++) {
           NSMutableAttributedString * attri = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@号       ",self.nums[i]] attributes:
                                                 @{NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                                                                                                              NSFontAttributeName:[UIFont systemFontOfSize:20]}];
            [result appendAttributedString:attri];
            
        }

        //延迟一下会执行
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.prizeLabel.attributedText = result;
        });
        
    }];
    
}
#pragma mark - 动画开始
-(void)animationStart{
    //只要开始动画，就让全屏的按钮无法使用，只有结束按钮
    for (UIView * view in self.view.subviews) {
        view.userInteractionEnabled = NO;
    }
    self.endBtn.userInteractionEnabled = YES;
    self.endBtn.enabled = YES;
    //移动的距离
    [UIView animateKeyframesWithDuration:0.4 delay:0 options:0 animations:^{
       
       for (int i = 0; i<self.imageViews.count; i++) {
           UIImageView * view = self.imageViews[i];
           view.y -= 106;
       }
       for (int i = 0; i<self.imageViews.count; i++) {
           UILabel * label = self.labels[i];
           label.text = [NSString stringWithFormat:@"%d",arc4random_uniform(10)];
       }
   } completion:^(BOOL finished) {
       for (int i = 0; i<self.imageViews.count; i++) {
           UIImageView * view = self.imageViews[i];
           view.y += 106;
       }
   }];

}
#pragma  mark - 选择个数
-(void)chooseNum:(UIButton *)sender{
    NSLog(@"%s",__func__);
    //隐藏屏幕上的的动画
    for (int i = 0; i<8; i++) {
        UIImageView * view = self.imageViews[i];
        view.hidden = YES;
        UILabel * label = self.labels[i];
        label.text = @"";
    }

    //打开开始按钮
    self.startBtn.enabled = YES;
    int num = sender.titleLabel.text.intValue;
    //判断是几个动画，设置他们的frame
    self.chooseNum = num;
    switch (self.chooseNum) {
        case 1:
        {
            //开启一个动画
            UIImageView * view1 = self.imageViews[0];
            UIImageView * view2 = self.imageViews[4];
            //移动他们的x值
            view1.x = self.view.center.x-40;
            view2.x = self.view.center.x-40;
            
            view1.hidden = NO;
            view2.hidden = NO;
            
        }
            break;
        case 2:
        {
            //开启两个个动画
            UIImageView * view1 = self.imageViews[0];
            UIImageView * view2 = self.imageViews[4];
            UIImageView * view3 = self.imageViews[1];
            UIImageView * view4 = self.imageViews[5];
            //移动他们的x值
            view1.x = self.view.center.x-120;
            view2.x = self.view.center.x-120;
            view3.x = self.view.center.x+40;
            view4.x = self.view.center.x+40;
            
            view1.hidden = NO;
            view2.hidden = NO;
            view3.hidden = NO;
            view4.hidden = NO;
            
        }

            break;
        case 3:
        {
            //开启两个个动画
            UIImageView * view1 = self.imageViews[0];
            UIImageView * view2 = self.imageViews[4];
            UIImageView * view3 = self.imageViews[1];
            UIImageView * view4 = self.imageViews[5];
            UIImageView * view5 = self.imageViews[2];
            UIImageView * view6 = self.imageViews[6];
            //移动他们的x值
            view1.x = 40;
            view2.x = 40;
            view3.x = 160;
            view4.x = 160;
            view5.x = 280;
            view6.x = 280;
            
            view1.hidden = NO;
            view2.hidden = NO;
            view3.hidden = NO;
            view4.hidden = NO;
            view5.hidden = NO;
            view6.hidden = NO;
            
        }

            break;
        case 4:
        {
            //创建动画图
            CGFloat margin = 26;
            CGFloat viewH = 80;
            CGFloat viewW = viewH;
            for (int i = 0; i < 8; i++) {
                UIImageView * view = self.imageViews[i];
                int col = i %4;
                int row = i /4;
                view.frame = CGRectMake(13+col * (viewW +13), margin+row * (viewW +margin), viewW, viewH);
                view.hidden = NO;
            }

        }
            break;
            
        default:
            break;
    }
}
//产生随机数算法2
//后期可让用户输入既有的数组，在数组中产生十个随机数
#pragma mark - 产生随机数组
-(NSArray *)makeArcdom:(int)num{
    //假设用户输入的数组为1到10
    NSMutableArray * tempArr = [NSMutableArray array];
    for (int i = 0; i<10; i++) {
        [tempArr addObject:[NSString stringWithFormat:@"%d",(i+1)]];
    }
    //实现随机产生十个数
    NSMutableArray * resultArr =[NSMutableArray array];
    int flag = 0;
    for (int i = 0; i<num; i++) {
        int tempIndex = arc4random_uniform(num - flag);
        [resultArr addObject:tempArr[tempIndex]];
        //把源数组的最后一项，移动到产生随机的地方，不断缩小取值范围
        [tempArr replaceObjectAtIndex:tempIndex withObject:tempArr[tempArr.count -1-flag]];
        flag ++ ;
    }
    return resultArr.copy;
}
  
#pragma mark -提示信息
-(void)remindMessage:(NSString *)text{
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"提示" message:text preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //移除掉
        [alert dismissViewControllerAnimated:YES completion:^{
            return ;
        }];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
    self.startBtn.enabled = NO;
    
}
    
#pragma mark -动画
-(void)mansu:(int)duration{
    //移动的距离
    [UIView animateKeyframesWithDuration:duration delay:0 options:0 animations:^{
        
        for (int i = 0; i<self.imageViews.count; i++) {
            UIImageView * view = self.imageViews[i];
            view.y -= 106;
        }
        for (int i = 0; i<self.imageViews.count; i++) {
            UILabel * label = self.labels[i];
            label.text = [NSString stringWithFormat:@"%d",arc4random_uniform(10)];
        }
    } completion:^(BOOL finished) {
        for (int i = 0; i<self.imageViews.count; i++) {
            UIImageView * view = self.imageViews[i];
            view.y += 106;
        }
    }];
    
}
@end
