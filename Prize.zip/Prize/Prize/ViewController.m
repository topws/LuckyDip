//
//  ViewController.m
//  Prize
//
//  Created by 钱卫 on 16/3/8.
//  Copyright © 2016年 钱卫. All rights reserved.
//

#import "ViewController.h"
#import "UIView+Additions.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *firstImageView;
@property (weak, nonatomic) IBOutlet UILabel *firstLabel;
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet UIImageView *secondImageView;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;
@property (assign) CGRect originalFramefirstImageView;
@property (assign) CGRect originalFramesecondImageView;

//存放随机数的数组
@property (nonatomic,strong)NSArray * nums;
@property (nonatomic,assign)int flag;
//动画定时器
@property (weak, nonatomic) IBOutlet UIView *view3;
@property (weak, nonatomic) IBOutlet UIView *view4;
@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (weak, nonatomic) IBOutlet UILabel *label4;
@property(nonatomic,strong)NSTimer *timer;

@end

@implementation ViewController
- (IBAction)didClickChangeImages:(UIButton *)sender {
    NSLog(@"改变图片框的个数");
}
//结束动画
- (IBAction)endBtn:(id)sender {
    //移除定时器
    [self.timer invalidate];
    self.timer = nil;
   
    //追加减速动画
    [UIView animateKeyframesWithDuration:1.0 delay:0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        self.firstImageView.y += 180;
        self.secondImageView.y += 180;
        self.firstLabel.text = [NSString stringWithFormat:@"%d",arc4random()%100];
        self.secondLabel.text =  [NSString stringWithFormat:@"%d",arc4random()%100];
        
    } completion:^(BOOL finished) {
        self.firstImageView.frame = self.originalFramefirstImageView;
        self.secondImageView.frame = self.originalFramesecondImageView;
    }];
    
    [UIView animateKeyframesWithDuration:1.3 delay:0 options:0 animations:^{
        self.view3.y += 180;
        self.view4.y += 180;
        self.label3.text = [NSString stringWithFormat:@"%d",arc4random()%100];
        self.label4.text =  [NSString stringWithFormat:@"%d",arc4random()%100];
        
    } completion:^(BOOL finished) {
        self.view3.y = self.originalFramefirstImageView.origin.y;
        self.view4.y = self.originalFramesecondImageView.origin.y;
    }];

    //默认是十个数
    self.firstLabel.text = [NSString stringWithFormat:@"%@",self.nums[self.flag]];
    //每一次的赋值都让计数器加一
    self.flag ++;
    
    self.label3.text = [NSString stringWithFormat:@"%@",self.nums[self.flag]];
    self.flag ++;
}
- (IBAction)ClickBtn:(id)sender {
    UIButton * btn = sender;
    //判断flag的值，如果已经大于十了，那就无法继续
//    if (btn.titleLabel.text.intValue > 4 - self.flag ) {
//        UIAlertController * alert =[UIAlertController alertControllerWithTitle:@"提示" message:@"最多产生十个人" preferredStyle:UIAlertControllerStyleAlert];
//        [self presentViewController:alert animated:YES completion:^{
//        }];
//        return;
//    }
    //开启定时器，实现无线循环
     NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(testAnimation) userInfo:nil repeats:YES];
    
    self.timer = timer ;
}
-(void)testAnimation{
    [UIView animateKeyframesWithDuration:0.4 delay:0 options:0 animations:^{
        self.firstImageView.y += 180;
        self.secondImageView.y += 180;
        self.firstLabel.text = [NSString stringWithFormat:@"%d",arc4random()%100];
        self.secondLabel.text =  [NSString stringWithFormat:@"%d",arc4random()%100];
    } completion:^(BOOL finished) {
        self.firstImageView.frame = self.originalFramefirstImageView;
        self.secondImageView.frame = self.originalFramesecondImageView;
    }];

    //为了达到不同速度的动画
    [UIView animateKeyframesWithDuration:0.4 delay:0 options:0 animations:^{
        self.view3.y  += 180;
        self.view4.y += 180;
        self.label3.text = [NSString stringWithFormat:@"%d",arc4random()%100];
        self.label4.text = [NSString stringWithFormat:@"%d",arc4random()%100];
        
    } completion:^(BOOL finished) {
        self.view3.y = self.originalFramefirstImageView.origin.y;
        self.view4.y = self.originalFramesecondImageView.origin.y;
    }];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    //前期思路不清晰，导致了下面两句冗余代码，可以直接跳过
    [self.firstImageView addSubview:self.firstLabel];
    [self.secondImageView addSubview:self.secondLabel];
    //获取初始化的位置
    self.originalFramefirstImageView = self.firstImageView.frame;
    self.originalFramesecondImageView = self.secondImageView.frame;
    self.backView.clipsToBounds = YES;
    
    //获取随机数列表
    self.nums = [self makeArcdom:10];
    self.flag = 0;
}

//产生随机数算法2
//后期可让用户输入既有的数组，在数组中产生十个随机数
-(NSArray *)makeArcdom:(int)num{
    //假设用户输入的数组为1到10
    NSMutableArray * tempArr = [NSMutableArray array];
    for (int i = 0; i<10; i++) {
        [tempArr addObject:[NSString stringWithFormat:@"%d",(i+1)]];
    }
    //实现随机产生十个数
    NSMutableArray * resultArr =[NSMutableArray array];
    int flag = 0;
    for (int i = 0; i<num; i++) {
        int tempIndex = arc4random_uniform(num - flag);
        [resultArr addObject:tempArr[tempIndex]];
        //把源数组的最后一项，移动到产生随机的地方，不断缩小取值范围
        [tempArr replaceObjectAtIndex:tempIndex withObject:tempArr[tempArr.count -1-flag]];
        flag ++ ;
    }
    return resultArr.copy;
}
////产生随机数算法1
//-(NSMutableArray *)makeArcdom:(int)modenNum{
//    
//    NSMutableArray *tempArray=[NSMutableArray array];
//    for (int i=0; i<modenNum; i++) {
//        
//        NSString *numStr=@"";
//        
//        numStr=[NSString stringWithFormat:@"%d",arc4random_uniform(modenNum)+1];
//        while([tempArray containsObject:numStr]) {
//            
//            numStr=[NSString stringWithFormat:@"%d",arc4random_uniform(modenNum)+1];
//        }
//        
//        [tempArray addObject:numStr];
//    }
//    return tempArray;
//}
@end
